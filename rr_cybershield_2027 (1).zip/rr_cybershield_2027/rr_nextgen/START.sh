#!/bin/bash
# ═══════════════════════════════════════════════════
#  RR CyberShield 2027 — Quick Start
#  Run this once to install and launch
# ═══════════════════════════════════════════════════

RED='\033[91m'; GRN='\033[92m'; YEL='\033[93m'
CYN='\033[96m'; BO='\033[1m'; RE='\033[0m'

echo -e "${CYN}${BO}"
echo "╔══════════════════════════════════════════════════╗"
echo "║   RR CyberShield 2027 — Kali Linux Setup       ║"
echo "╚══════════════════════════════════════════════════╝"
echo -e "${RE}"

# Install dependencies
echo -e "${YEL}[1/2] Installing Python packages...${RE}"
pip3 install flask flask-cors requests --break-system-packages -q
echo -e "${GRN}  [✓] Packages ready${RE}"

echo -e "${YEL}[2/2] Launching dashboard server...${RE}"
echo ""
echo -e "${CYN}${BO}  ┌─────────────────────────────────────────────┐"
echo -e "  │  TERMINAL 1 (this window) = Web Server     │"
echo -e "  │  TERMINAL 2 (new window)  = Attack runner  │"
echo -e "  └─────────────────────────────────────────────┘${RE}"
echo ""
echo -e "${GRN}  Dashboard → http://localhost:5000${RE}"
echo -e "${GRN}  Open Firefox: firefox http://localhost:5000 &${RE}"
echo ""
echo -e "${YEL}  In Terminal 2, run attacks:${RE}"
echo -e "  ${BO}python3 attacker.py --interactive${RE}   ← menu mode"
echo -e "  ${BO}python3 attacker.py --attack can${RE}    ← CAN bus attacks"
echo -e "  ${BO}python3 attacker.py --attack voice${RE}  ← AI voice clone"
echo -e "  ${BO}python3 attacker.py --all${RE}           ← ALL attacks"
echo ""
echo -e "${RED}  Press Ctrl+C to stop server${RE}"
echo ""

# Open Firefox in background
firefox http://localhost:5000 2>/dev/null &

# Start server
python3 server.py
