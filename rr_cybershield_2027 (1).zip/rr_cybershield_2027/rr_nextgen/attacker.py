#!/usr/bin/env python3
"""
RR CyberShield 2027 — ATTACKER TERMINAL
Terminal 2: Run attacks that appear LIVE on the dashboard

Usage:
  python3 attacker.py --attack can       # CAN bus injection
  python3 attacker.py --attack rf        # RF relay attack
  python3 attacker.py --attack voice     # AI voice clone
  python3 attacker.py --attack ota       # Firmware hijack
  python3 attacker.py --attack v2x       # V2X fake signal
  python3 attacker.py --attack mobile    # Impossible travel
  python3 attacker.py --attack obd       # OBD-II probe
  python3 attacker.py --attack gps       # GPS spoofing
  python3 attacker.py --attack supply    # Supply chain
  python3 attacker.py --attack ai        # AI prediction demo
  python3 attacker.py --all              # Run ALL attacks
  python3 attacker.py --interactive      # Menu mode
"""

import sys, os, time, json, argparse, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import requests
except ImportError:
    os.system("pip3 install requests --break-system-packages -q")
    import requests

SERVER = "http://localhost:5000"

# ── colors ───────────────────────────────────────────
R  = "\033[91m"   # red
G  = "\033[92m"   # green
Y  = "\033[93m"   # yellow
B  = "\033[94m"   # blue
P  = "\033[95m"   # purple
C  = "\033[96m"   # cyan
W  = "\033[97m"   # white
DIM= "\033[2m"
BO = "\033[1m"
RE = "\033[0m"

def clr():  os.system("clear")
def ts():   return time.strftime("%H:%M:%S")
def ok(m):  print(f"  {G}{BO}[✓]{RE} {m}")
def atk(m): print(f"  {R}{BO}[ATK]{RE} {m}")
def blk(m): print(f"  {G}[BLOCKED]{RE} {m}")
def inf(m): print(f"  {B}[i]{RE} {m}")
def sec(m): print(f"  {C}[SYSTEM]{RE} {m}")
def pred(m):print(f"  {P}[AI-PRED]{RE} {m}")
def pause(n=0.6): time.sleep(n)

def send(payload: dict):
    """Send attack to dashboard — returns True if blocked"""
    try:
        r = requests.post(f"{SERVER}/attack", json=payload, timeout=3)
        return r.json().get("blocked", True)
    except Exception as e:
        print(f"  {Y}[!] Dashboard not reachable: {e}{RE}")
        print(f"  {Y}    Start Terminal 1 first: python3 server.py{RE}")
        return False

def banner(title, color=R):
    print(f"\n{color}{BO}{'═'*58}{RE}")
    print(f"{color}{BO}  ⚡ {title}{RE}")
    print(f"{color}{BO}{'═'*58}{RE}\n")

def hr():
    print(f"  {DIM}{'─'*54}{RE}")

# ════════════════════════════════════════════════════
#  ATTACK 1 — CAN BUS
# ════════════════════════════════════════════════════
def attack_can():
    banner("CAN BUS INJECTION ATTACKS", R)
    inf(f"Target: Range Rover EVA 2.0 — 63 ECUs on CAN-FD bus")
    inf(f"Tool  : Custom CAN frame injector")
    pause()

    attacks_can = [
        {
            "name": "Engine RPM Overflow",
            "frame_id": "0x12F",
            "payload": "FF FF FF FF FF FF FF FF",
            "description": "Setting engine RPM to 65,535 → redline damage",
            "impact": "ENGINE DAMAGE / VEHICLE IMMOBILIZATION",
            "detail": "CAN ID 0x12F payload 0xFFFF exceeds physical max (7000 RPM) → IDS rule triggered"
        },
        {
            "name": "Door Unlock Replay",
            "frame_id": "0x700",
            "payload": "0F 00 00 00 00 00 00 00",
            "description": "Replaying captured door unlock CAN frame",
            "impact": "ALL DOORS UNLOCK — VEHICLE THEFT",
            "detail": "Simultaneous 4-door unlock pattern → replay attack signature detected"
        },
        {
            "name": "CAN Bus DoS Flood",
            "frame_id": "0x000",
            "payload": "00 00 00 00 00 00 00 00",
            "description": "Priority-0 frame flood — saturates bus bandwidth",
            "impact": "ALL ECU COMMS DISRUPTED",
            "detail": "Unknown CAN ID 0x000 not in ECU whitelist → firewall drops"
        },
        {
            "name": "ADAS Brake Spoof",
            "frame_id": "0x4B0",
            "payload": "AA FF 00 00 FF FF 00 00",
            "description": "Fake emergency brake on ADAS bus at 110km/h",
            "impact": "SUDDEN BRAKING — ACCIDENT",
            "detail": "ADAS frame with saturated payload → attack signature database match"
        },
        {
            "name": "ECU Firmware Flash",
            "frame_id": "0x7DF",
            "payload": "DE AD BE EF 00 00 00 FF",
            "description": "Unauthorised flash via OBD-II broadcast (0xDEADBEEF)",
            "impact": "MALWARE FLASHED TO 63 ECUs",
            "detail": "Magic bytes 0xDEADBEEF = known flash initiation signature → blocked"
        },
    ]

    for a in attacks_can:
        print(f"\n  {R}{BO}┌─ INJECTING: {a['name']}{RE}")
        print(f"  {Y}│  Frame ID : {a['frame_id']}{RE}")
        print(f"  {Y}│  Payload  : {a['payload']}{RE}")
        print(f"  {Y}│  Goal     : {a['description']}{RE}")
        print(f"  {R}│  Impact   : {a['impact']}{RE}")
        pause(0.5)

        print(f"  {DIM}│  Sending frame to CAN bus...{RE}")
        pause(0.8)

        blocked = send({
            "type": "can_injection",
            "severity": "critical",
            "name": f"CAN: {a['name']}",
            "detail": a['detail'],
            "blocked": True,
            "module": "CAN-IDS"
        })

        if blocked:
            blk(f"IDS: {a['detail']}")
            print(f"  {G}└─ Frame DROPPED. ECU safe. SOC alerted. ✓{RE}")
        else:
            print(f"  {R}└─ Frame ACCEPTED — ATTACK SUCCEEDED{RE}")
        hr()
        pause(0.4)

    print(f"\n  {G}{BO}CAN Bus: 5/5 attacks blocked ✓{RE}\n")

# ════════════════════════════════════════════════════
#  ATTACK 2 — RF RELAY
# ════════════════════════════════════════════════════
def attack_rf():
    banner("RF KEY FOB — RELAY + REPLAY ATTACK", R)
    inf("Tool: HackRF One + Proxmark3")
    inf("Target: 433MHz key fob signal")
    pause()

    # Phase 1: Relay
    print(f"\n  {R}{BO}[ PHASE 1 ] Classic Relay Attack{RE}")
    atk("Attacker A: standing near car with relay device")
    atk("Attacker B: standing 15m away near house entrance")
    pause(0.5)
    atk("Amplifying key fob signal across 15 metres...")
    pause(0.8)
    print(f"\n  {Y}  Without UWB:  Car UNLOCKS ← no distance check{RE}")
    print(f"  {Y}  Impact: Vehicle stolen in 60 seconds{RE}")
    pause(0.5)

    send({
        "type": "rf_relay",
        "severity": "critical",
        "name": "RF Relay Attack (key fob amplification 15m)",
        "detail": "UWB ToF mismatch: reported 38cm vs actual 2670cm → relay detected → car stays LOCKED",
        "blocked": True,
        "module": "RF/UWB"
    })

    print(f"\n  {G}  With UWB defense:{RE}")
    ok("UWB Time-of-Flight: reported 38cm vs measured 2670cm")
    blk("Distance mismatch → relay attack → car stays LOCKED ✓")
    hr()
    pause(0.5)

    # Phase 2: Replay
    print(f"\n  {R}{BO}[ PHASE 2 ] SDR Replay Attack{RE}")
    atk("Capturing key fob signal with RTL-SDR ($25 device)...")
    pause(0.6)
    code = f"{random.randint(0x1000,0xFFFF):04x}{random.randint(0x1000,0xFFFF):04x}"
    atk(f"Captured rolling code: {code} (counter: 1000)")
    pause(0.4)
    atk(f"Replaying code: {code}...")
    pause(0.8)

    send({
        "type": "rf_replay",
        "severity": "high",
        "name": f"RF Replay: captured code {code}",
        "detail": "Code counter 1000 already consumed in used_codes set → replay rejected → locked",
        "blocked": True,
        "module": "RF/UWB"
    })

    blk(f"REPLAY DETECTED: code {code} already used (nonce consumed) ✓")
    print(f"  {G}  Rolling code nonce: one-time use, cannot replay{RE}\n")

# ════════════════════════════════════════════════════
#  ATTACK 3 — AI VOICE CLONE
# ════════════════════════════════════════════════════
def attack_voice():
    banner("AI VOICE CLONE ATTACK", P)
    inf("Tool: ElevenLabs API voice synthesis")
    inf("Target: Alexa 'Hey Alexa, unlock doors'")
    pause()

    print(f"\n  {P}{BO}[ PHASE 1 ] Collecting owner voice samples{RE}")
    atk("Sourcing voice samples from YouTube/social media...")
    pause(0.5)
    for i in range(1, 5):
        atk(f"Sample {i}/4 collected ({random.randint(8,15)}s clip)")
        pause(0.3)

    print(f"\n  {P}{BO}[ PHASE 2 ] Synthesising clone{RE}")
    atk("ElevenLabs API: cloning voice model...")
    pause(0.7)
    atk('Synthesising: "Hey Alexa, unlock doors"')
    pause(0.5)
    atk("Playing via Bluetooth speaker near car window...")
    pause(0.8)

    print(f"\n  {C}{BO}[ DEFENSE ] Liveness detection pipeline{RE}")
    pause(0.4)
    print(f"  {B}  d-vector voiceprint   : 0.91 ← clone is GOOD{RE}")
    pause(0.3)
    print(f"  {R}  Liveness score        : 0.12 / threshold 0.70 ← FAKE{RE}")
    pause(0.3)
    print(f"  {R}  GAN fingerprint       : detected at 3.2kHz{RE}")
    pause(0.3)
    print(f"  {R}  Phase discontinuity   : detected ← synthetic artifact{RE}")
    pause(0.5)

    send({
        "type": "voice_clone",
        "severity": "critical",
        "name": "AI Voice Clone — 'unlock doors' (ElevenLabs)",
        "detail": "Liveness score 0.12/0.70 · GAN fingerprint @ 3.2kHz · challenge-response failed → BLOCKED",
        "blocked": True,
        "module": "AI-VOICE"
    })

    blk("VOICE CLONE BLOCKED · liveness 0.12 < 0.70 ✓")

    print(f"\n  {P}{BO}[ PHASE 3 ] Challenge-Response test{RE}")
    pause(0.4)
    print(f"  {C}  Car: 'Say today's number: {random.randint(1000,9999)}'{RE}")
    pause(0.3)
    atk("Clone attempts to replay pre-recorded number...")
    pause(0.5)
    print(f"  {R}  Response timing: 84ms (avg human: 920ms) → BOT{RE}")
    blk("Challenge-response: timing anomaly → BLOCKED ✓\n")

# ════════════════════════════════════════════════════
#  ATTACK 4 — OTA FIRMWARE HIJACK
# ════════════════════════════════════════════════════
def attack_ota():
    banner("OTA FIRMWARE HIJACK", Y)
    inf("Scenario: Man-in-the-middle during software update")
    inf("Tool: Rogue WiFi AP + custom firmware bundle")
    pause()

    print(f"\n  {R}{BO}[ PHASE 1 ] Rogue OTA server setup{RE}")
    atk("Standing up fake ota.jlr.com on 192.168.1.100...")
    atk("DNS spoofing: ota.jlr.com → 192.168.1.100")
    atk("Rogue TLS cert: CN=ota.jlr.com (self-signed)")
    pause(0.8)

    print(f"\n  {R}{BO}[ PHASE 2 ] Malicious firmware prepared{RE}")
    fw_hash = f"{random.randint(0x10000000,0xFFFFFFFF):08x}{random.randint(0x10000000,0xFFFFFFFF):08x}"
    atk(f"Malware payload hash: {fw_hash}...")
    atk("Injecting: remote shell + CAN backdoor + keylogger")
    pause(0.6)

    print(f"\n  {C}{BO}[ DEFENSE ] 5-layer OTA pipeline{RE}")
    checks = [
        ("TLS 1.3 mutual auth", True),
        ("Certificate pinning check", True),
        ("SHA-256 manifest checksum", True),
        ("RSA-4096 signature verify", False),  # fails — rogue key
    ]
    for name, passed in checks:
        pause(0.35)
        if passed:
            ok(f"{name} → PASS")
        else:
            print(f"  {R}[✗]{RE} {name} → FAIL (rogue key not trusted)")

    pause(0.4)

    send({
        "type": "ota_hijack",
        "severity": "critical",
        "name": f"OTA Firmware Hijack — malware {fw_hash[:12]}...",
        "detail": "RSA-4096 signature mismatch · rogue cert not pinned · flash ABORTED · rollback retained",
        "blocked": True,
        "module": "OTA"
    })

    blk("Firmware flash ABORTED · previous version retained ✓")
    ok("Dual-bank: Bank A firmware intact · no disruption\n")

# ════════════════════════════════════════════════════
#  ATTACK 5 — V2X FAKE SIGNAL
# ════════════════════════════════════════════════════
def attack_v2x():
    banner("V2X FAKE TRAFFIC SIGNAL", Y)
    inf("Tool: GNU Radio + 5.9GHz DSRC SDR transmitter")
    inf("Target: Vehicle-to-Infrastructure (V2I) channel")
    pause()

    atk("Broadcasting fake IEEE 802.11p frame...")
    atk("Signal: 'Traffic light AHEAD = GREEN, speed = 80km/h'")
    atk("Broadcast power: 23dBm · range 300m")
    pause(0.8)

    print(f"\n  {C}{BO}[ DEFENSE ] V2X trust pipeline{RE}")
    pause(0.3)
    print(f"  {R}[✗]{RE} IEEE 1609.2 certificate: SELF-SIGNED (not in ETSI trust store)")
    pause(0.3)
    print(f"  {R}[✗]{RE} ECDSA-256 signature: INVALID")
    pause(0.3)
    print(f"  {R}[✗]{RE} Message trust score: 0.04 / 1.00")
    pause(0.3)

    send({
        "type": "v2x_spoof",
        "severity": "high",
        "name": "V2X Fake Green Signal (DSRC 5.9GHz)",
        "detail": "IEEE 1609.2 cert invalid · ECDSA fail · trust score 0.04 → signal REJECTED · car ignores",
        "blocked": True,
        "module": "V2X"
    })

    blk("Fake V2X signal REJECTED · car uses real sensor data ✓\n")

# ════════════════════════════════════════════════════
#  ATTACK 6 — IMPOSSIBLE TRAVEL
# ════════════════════════════════════════════════════
def attack_mobile():
    banner("MOBILE APP — IMPOSSIBLE TRAVEL", C)
    inf("Attack: stolen session token used from different country")
    pause()

    atk("Session A: Login Colombo, Sri Lanka — 04:15:02 UTC")
    pause(0.3)
    atk("Stolen token replayed from Frankfurt, Germany — 04:19:14 UTC")
    pause(0.6)

    print(f"\n  {C}{BO}[ DEFENSE ] Geo-velocity analysis{RE}")
    pause(0.3)
    print(f"  {B}  Distance : 8,247 km{RE}")
    print(f"  {B}  Time gap : 4 minutes 12 seconds{RE}")
    print(f"  {B}  Required : 10h 30min minimum (flight){RE}")
    print(f"  {R}  Verdict  : IMPOSSIBLE → session token stolen{RE}")
    pause(0.5)

    send({
        "type": "impossible_travel",
        "severity": "critical",
        "name": "Impossible Travel: Sri Lanka→Germany in 4min",
        "detail": "8,247km in 4min → physically impossible · session B killed · owner alerted · remote commands disabled",
        "blocked": True,
        "module": "MOBILE"
    })

    blk("Session B KILLED · remote park + doors disabled ✓")
    ok("Owner notified via push notification\n")

# ════════════════════════════════════════════════════
#  ATTACK 7 — OBD-II PROBE
# ════════════════════════════════════════════════════
def attack_obd():
    banner("OBD-II UNAUTHORIZED ACCESS", Y)
    inf("Tool: ELM327 dongle (Amazon £8)")
    inf("Scenario: Attacker breaks into parked car")
    pause()

    atk("Plugging ELM327 dongle into OBD-II port...")
    pause(0.5)
    atk("Sending: ATZ (reset) → ATE0 → ATSP0 (auto protocol)")
    pause(0.4)
    atk("Attempting diagnostic session: 0x10 0x03...")
    pause(0.7)

    send({
        "type": "obd2_probe",
        "severity": "high",
        "name": "OBD-II Probe: ELM327 unauthorized access",
        "detail": "Tool certificate missing · not in authorised list · port locked while parked >30min · session rejected",
        "blocked": True,
        "module": "OBD-II"
    })

    blk("OBD-II port: LOCKED · certificate required ✓")
    ok("Port auto-locks after 30min unattended parking\n")

# ════════════════════════════════════════════════════
#  ATTACK 8 — GPS SPOOF
# ════════════════════════════════════════════════════
def attack_gps():
    banner("GPS SPOOFING → ADAS CONFUSION", R)
    inf("Tool: HackRF + GPS-SDR-SIM")
    inf("Target: Force wrong location → confuse ADAS cruise control")
    pause()

    atk("Broadcasting fake GPS: 51.5074, -0.1278 (London)")
    atk("Real location: 51.4545, -0.9704 (Reading, M4 motorway)")
    pause(0.6)
    atk("Fake speed in signal: 5 km/h (real: 82 km/h)")
    pause(0.8)

    print(f"\n  {C}{BO}[ DEFENSE ] Multi-sensor fusion{RE}")
    pause(0.3)
    print(f"  {B}  GPS (spoofed)  : 5 km/h  heading=E{RE}")
    print(f"  {B}  Wheel speed    : 82 km/h{RE}")
    print(f"  {B}  IMU accelerom. : 81.5 km/h{RE}")
    print(f"  {B}  Camera flow    : 83 km/h{RE}")
    print(f"  {R}  Delta          : 77 km/h gap → SPOOFED{RE}")
    pause(0.5)

    send({
        "type": "gps_spoof",
        "severity": "high",
        "name": "GPS Spoofing: London coords at 5km/h (real: 82km/h)",
        "detail": "Speed delta 77km/h vs IMU · heading 180° mismatch · GPS flagged → ADAS uses wheel+camera+radar",
        "blocked": True,
        "module": "ADAS/GPS"
    })

    blk("GPS flagged as spoofed · ADAS falls back to IMU+camera ✓\n")

# ════════════════════════════════════════════════════
#  ATTACK 9 — SUPPLY CHAIN
# ════════════════════════════════════════════════════
def attack_supply():
    banner("SOFTWARE SUPPLY CHAIN ATTACK", P)
    inf("Scenario: Third-party navigation library tampered")
    pause()

    lib = "third-party-nav-lib"
    expected = "a3f9e2b1c4d5e6f7"
    actual   = "deadbeef00000000"

    atk(f"Attacker modified: {lib} v2.1.3")
    atk(f"Injected: CAN backdoor + remote shell payload")
    pause(0.6)

    print(f"\n  {C}{BO}[ DEFENSE ] SBOM verification{RE}")
    pause(0.4)
    print(f"  {B}  Expected hash : {expected}{RE}")
    print(f"  {R}  Actual hash   : {actual}{RE}")
    print(f"  {R}  MISMATCH DETECTED{RE}")
    pause(0.5)

    send({
        "type": "supply_chain",
        "severity": "critical",
        "name": f"Supply Chain: {lib} v2.1.3 tampered",
        "detail": f"SBOM hash mismatch: expected {expected} got {actual} · OTA rollback initiated · library quarantined",
        "blocked": True,
        "module": "SUPPLY"
    })

    blk("Compromised library QUARANTINED · OTA rollback started ✓\n")

# ════════════════════════════════════════════════════
#  ATTACK 10 — AI PREDICTION DEMO
# ════════════════════════════════════════════════════
def attack_ai():
    banner("AI THREAT PREDICTION ENGINE", P)
    inf("Showing AI predicting attack BEFORE it happens")
    pause()

    print(f"\n  {P}{BO}[ AI OBSERVING SIGNALS ]{RE}")
    signals = [
        ("RF scan event #1", "Unknown device scanning 433MHz"),
        ("RF scan event #2", "Same device, 3 min later"),
        ("Bluetooth probe",  "Unknown MAC attempting pairing"),
        ("RF scan event #3", "Device now 8m from vehicle"),
        ("CAN minor anomaly","Slight timing jitter on 0x1A5"),
    ]
    for name, detail in signals:
        pause(0.4)
        pred(f"{name}: {detail}")

    pause(0.5)
    print(f"\n  {P}{BO}[ AI LSTM MODEL INFERENCE ]{RE}")
    pause(0.6)
    print(f"  {P}  Pattern match: relay attack signature (seen 47x in training){RE}")
    print(f"  {P}  Confidence   : 87%{RE}")
    print(f"  {P}  ETA          : ~12 minutes{RE}")

    send({
        "type": "ai_prediction",
        "severity": "ai_pred",
        "name": "AI PREDICTION: Relay attack 87% likely in ~12 min",
        "detail": "Signals: RF scan ×3 + BT probe + CAN jitter → LSTM 87% confidence · UWB tightened to 0.5m",
        "blocked": True,
        "module": "AI-ENGINE"
    })

    pred("ACTION: UWB threshold → 0.5m · driver notified · SOC on standby ✓\n")

# ════════════════════════════════════════════════════
#  INTERACTIVE MENU
# ════════════════════════════════════════════════════
def interactive():
    menu = {
        "1": ("CAN Bus Injection (5 attacks)",  attack_can),
        "2": ("RF Relay + Replay",               attack_rf),
        "3": ("AI Voice Clone",                  attack_voice),
        "4": ("OTA Firmware Hijack",             attack_ota),
        "5": ("V2X Fake Signal",                 attack_v2x),
        "6": ("Impossible Travel (Mobile)",      attack_mobile),
        "7": ("OBD-II Probe",                    attack_obd),
        "8": ("GPS Spoofing",                    attack_gps),
        "9": ("Supply Chain Attack",             attack_supply),
        "0": ("AI Prediction Demo",              attack_ai),
        "A": ("Run ALL attacks",                 run_all),
    }
    while True:
        print(f"\n{R}{BO}╔══════════════════════════════════════╗")
        print(f"║   RR ATTACKER — Select Attack        ║")
        print(f"╚══════════════════════════════════════╝{RE}")
        for k, (name, _) in menu.items():
            print(f"  {Y}[{k}]{RE} {name}")
        print(f"  {DIM}[Q] Quit{RE}")
        choice = input(f"\n  {C}Select > {RE}").strip().upper()
        if choice == "Q": break
        if choice in menu:
            menu[choice][1]()
        else:
            print(f"  {Y}Invalid choice{RE}")

def run_all():
    clr()
    print(f"\n{R}{BO}{'═'*58}")
    print(f"  RR CyberShield 2027 — FULL ATTACK SEQUENCE")
    print(f"  Watch the dashboard: http://localhost:5000")
    print(f"{'═'*58}{RE}\n")
    pause(1)
    for fn in [attack_can, attack_rf, attack_voice, attack_ota,
               attack_v2x, attack_mobile, attack_obd, attack_gps,
               attack_supply, attack_ai]:
        fn()
        pause(0.5)
    print(f"\n{G}{BO}{'═'*58}")
    print(f"  ALL ATTACKS COMPLETE — Dashboard updated")
    print(f"{'═'*58}{RE}\n")

# ════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RR CyberShield Attacker Terminal")
    parser.add_argument("--attack", choices=["can","rf","voice","ota","v2x","mobile","obd","gps","supply","ai"])
    parser.add_argument("--all",         action="store_true")
    parser.add_argument("--interactive", action="store_true")
    args = parser.parse_args()

    # header
    print(f"\n{R}{BO}╔══════════════════════════════════════════════════╗")
    print(f"║   RR CyberShield 2027 — ATTACKER TERMINAL      ║")
    print(f"║   Dashboard: http://localhost:5000              ║")
    print(f"╚══════════════════════════════════════════════════╝{RE}")

    # check server
    try:
        requests.get(f"{SERVER}/status", timeout=2)
        print(f"  {G}[✓] Dashboard server reachable{RE}")
    except:
        print(f"  {Y}[!] Dashboard not running — start Terminal 1 first:{RE}")
        print(f"  {Y}    python3 server.py{RE}\n")

    if args.all:         run_all()
    elif args.interactive or not any(vars(args).values()):
                         interactive()
    elif args.attack == "can":    attack_can()
    elif args.attack == "rf":     attack_rf()
    elif args.attack == "voice":  attack_voice()
    elif args.attack == "ota":    attack_ota()
    elif args.attack == "v2x":    attack_v2x()
    elif args.attack == "mobile": attack_mobile()
    elif args.attack == "obd":    attack_obd()
    elif args.attack == "gps":    attack_gps()
    elif args.attack == "supply": attack_supply()
    elif args.attack == "ai":     attack_ai()
