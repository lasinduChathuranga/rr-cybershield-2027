#!/usr/bin/env python3
"""
RR CyberShield 2027 — Web Server
Terminal 1: python3 server.py
Terminal 2: python3 attacker.py --attack can
Dashboard opens at: http://localhost:5000
"""

import sys, os, json, time, threading, queue
from datetime import datetime

# ── install flask if needed ──────────────────────────
try:
    from flask import Flask, Response, send_file, jsonify, request
    from flask_cors import CORS
except ImportError:
    print("[*] Installing Flask...")
    os.system("pip3 install flask flask-cors --break-system-packages -q")
    from flask import Flask, Response, send_file, jsonify, request
    from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ── shared event queue (thread-safe) ────────────────
event_queue = queue.Queue()
attack_log  = []
stats = {
    "score": 97,
    "blocked": 14,
    "predictions": 2,
    "modules": 9,
    "start_time": datetime.now().isoformat()
}

COLORS = {
    "RESET":  "\033[0m",
    "GREEN":  "\033[92m",
    "RED":    "\033[91m",
    "YELLOW": "\033[93m",
    "CYAN":   "\033[96m",
    "BOLD":   "\033[1m",
    "DIM":    "\033[2m",
}
C = COLORS

def log(color, tag, msg):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"  {C['DIM']}[{ts}]{C['RESET']} {color}{C['BOLD']}[{tag}]{C['RESET']} {msg}")

# ── SSE helper ───────────────────────────────────────
def sse(data: dict) -> str:
    return f"data: {json.dumps(data)}\n\n"

# ── ROUTES ───────────────────────────────────────────
@app.route("/")
def index():
    return send_file("index.html")

@app.route("/stream")
def stream():
    """Server-Sent Events — dashboard subscribes here"""
    def gen():
        # send current stats on connect
        yield sse({"type": "init", "stats": stats, "log": attack_log[-20:]})
        while True:
            try:
                event = event_queue.get(timeout=25)
                yield sse(event)
            except queue.Empty:
                yield sse({"type": "ping"})   # keep-alive
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})

@app.route("/attack", methods=["POST"])
def receive_attack():
    """Attacker terminal POSTs here"""
    data = request.json
    if not data:
        return jsonify({"error": "no data"}), 400

    attack_type = data.get("type", "unknown")
    severity    = data.get("severity", "high")
    name        = data.get("name", "Unknown attack")
    detail      = data.get("detail", "")
    blocked     = data.get("blocked", True)
    module      = data.get("module", "IDS")

    ts = datetime.now().strftime("%H:%M:%S")
    entry = {
        "type":     "attack",
        "ts":       ts,
        "attack":   attack_type,
        "severity": severity,
        "name":     name,
        "detail":   detail,
        "blocked":  blocked,
        "module":   module
    }

    # update stats
    if blocked:
        stats["blocked"] += 1
        stats["score"] = max(70, stats["score"] - 1)
    attack_log.append(entry)
    if len(attack_log) > 100:
        attack_log.pop(0)

    entry["stats"] = {**stats}
    event_queue.put(entry)

    color = C["GREEN"] if blocked else C["RED"]
    status = "BLOCKED ✓" if blocked else "SUCCESS ✗"
    log(color, module, f"{name} → {status}")
    return jsonify({"ok": True, "blocked": blocked})

@app.route("/status")
def status():
    return jsonify(stats)

@app.route("/clear", methods=["POST"])
def clear():
    stats["score"] = 99
    stats["blocked"] = 0
    attack_log.clear()
    event_queue.put({"type": "clear"})
    return jsonify({"ok": True})

# ── STARTUP ──────────────────────────────────────────
if __name__ == "__main__":
    print(f"""
{C['CYAN']}{C['BOLD']}╔══════════════════════════════════════════════════╗
║   RR CyberShield 2027 — Web Dashboard Server    ║
╚══════════════════════════════════════════════════╝{C['RESET']}

  {C['GREEN']}Dashboard  →  http://localhost:5000{C['RESET']}
  {C['YELLOW']}API        →  http://localhost:5000/attack  (POST){C['RESET']}
  {C['DIM']}Stream     →  http://localhost:5000/stream (SSE){C['RESET']}

  {C['CYAN']}Open Terminal 2 and run:{C['RESET']}
  {C['BOLD']}  python3 attacker.py --attack can{C['RESET']}
  {C['BOLD']}  python3 attacker.py --attack rf{C['RESET']}
  {C['BOLD']}  python3 attacker.py --attack voice{C['RESET']}
  {C['BOLD']}  python3 attacker.py --all{C['RESET']}

  Press Ctrl+C to stop.
""")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
